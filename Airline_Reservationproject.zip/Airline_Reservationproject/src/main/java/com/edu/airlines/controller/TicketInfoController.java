package com.edu.airlines.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.edu.airlines.model.TicketInfo;
import com.edu.airlines.service.TicketInfoService;

@RestController
public class TicketInfoController {
	
	@Autowired
	private TicketInfoService ticketinfoservice;
	
	@GetMapping("/getTicketDetails")
	public List<TicketInfo> getTicketDetails()
	{
		return ticketinfoservice.getTicketDetails();
	}
	
	@PostMapping("/bookTicket")
	public ResponseEntity<TicketInfo> bookTicket(@Valid @RequestBody TicketInfo ticketInfo) {
		return new ResponseEntity<TicketInfo>(ticketinfoservice.bookTicket(ticketInfo),HttpStatus.CREATED);
		
	}
	@PutMapping ("/updateTicketInfoDetails/{ticketno}")
	public ResponseEntity<TicketInfo> updatetTicketInfoDetails(@PathVariable("ticketno") Integer ticketno,@RequestBody TicketInfo ticketinfo)
	{
		return new ResponseEntity<TicketInfo>(ticketinfoservice.updateTicketDetails(ticketno,ticketinfo),HttpStatus.OK);
	}
	
	@PutMapping("/ticketinfo/{ticketno}/passenger/{passengerid}")
	public ResponseEntity<TicketInfo> updatePassengerToTicketInfo(@PathVariable Integer ticketno, @PathVariable Integer passengerid)
	{
		return new ResponseEntity<TicketInfo>(ticketinfoservice.updatePassengerToTicketInfo(ticketno,passengerid), HttpStatus.OK);
	}
	
	@PutMapping("/ticketinfo/{ticketno}/flight/{flightno}")
	public ResponseEntity<TicketInfo> updateFlightToTicketInfo(@PathVariable Integer ticketno , @PathVariable Integer flightno)
	{
		return new ResponseEntity<TicketInfo>(ticketinfoservice.updateFlightToTicketInfo(ticketno, flightno) , HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteTicketDetailsById/{ticketno}")
	public ResponseEntity<String> deleteTicketDetailsById(@PathVariable("ticketno") Integer ticketno)
	{
		ticketinfoservice.deleteTicketDetails(ticketno);
		return new ResponseEntity<String>("Ticket details deleted successfully",HttpStatus.OK);
		}
	@GetMapping("/getTicketDetailsByCost/{cost}")
	public ResponseEntity<List<TicketInfo>>getTicketInfoDetailsByCost(@PathVariable("cost") Float cost)
	{
		return new ResponseEntity<List<TicketInfo>>(ticketinfoservice.getTicketDetailsByCost(cost),HttpStatus.OK);
	}
	
	@GetMapping("/getTicketDetailsByReservationClass/{reservationclass}")
	public ResponseEntity<List<TicketInfo>>getTicketInfoDetailsByReservationClass(@PathVariable("reservationclass") String reservationclass)
	{
		return new ResponseEntity<List<TicketInfo>>(ticketinfoservice.getTicketDetailsByReservationClass(reservationclass),HttpStatus.OK);
	}
	
	@GetMapping("/getTicketDetailsByReservationStatus/{reservationstatus}")
	public ResponseEntity<List<TicketInfo>>getTicketInfoDetailsByReservationStatus(@PathVariable("reservationstatus") String reservationstatus)
	{
		return new ResponseEntity<List<TicketInfo>>(ticketinfoservice.getTicketDetailsByReservationStatus(reservationstatus),HttpStatus.OK);
	}


}


