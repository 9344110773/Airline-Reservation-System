package com.edu.airlines.service;

import java.util.List;

import javax.validation.Valid;

import com.edu.airlines.model.Passenger;

public interface PassengerService {

	List<Passenger> getPassengers();

	Passenger registerPassenger(@Valid Passenger passenger);

	//Passenger updatePassengerDetails(Integer passengerid, Passenger passenger);

	void deletePassengerById(Integer passengerid);

	List<Passenger> findPassengerByPassengername(String passengername);

	List<Passenger> findPassengerByPassengerGender(String gender);

	Passenger findPassengerByEmail(String email);

	Passenger findPassengerByMobileno(String mobileno);

	List<Passenger> findPassengerByPassengerAddress(String address);

	Passenger updateFlighttoPassenger(Integer passengerid, Integer flightno);

	Passenger updatePassengerDetails(Integer passengerid, Passenger passenger);

}
