package com.edu.airlines.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import org.hibernate.validator.constraints.Length;

@Entity
@SequenceGenerator(name="passseq", initialValue = 5000)
@Table(name="passengertable")
public class Passenger {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "passseq")
	private Integer passengerid;
	@NotBlank(message="passengername should not be null")
	private String passengername;
	@NotBlank(message="gender should not be null")
	private String gender;
	@NotBlank(message="email id should not be blank")
	@Email(message="Enter valid email id")
	@Column(unique = true)
	private String email;
	@Length(min=10, max=10, message="Mobile number cannot be less than 10 numbers")
	@Column(unique = true)
	private String mobileno;
	@NotBlank(message="address should not be blank")
	private String address;
	@Length(min=12, max=12, message="Passport number cannot be less than 12 numbers")
	@Column(unique = true)
	private String passportnumber;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "flight_no" , referencedColumnName = "flightNo")
	private Flight flight; 
	
	
	//Generate default constructor
	public Passenger() {
		super();
	}

	//Generate Argument constructor
	public Passenger(Integer passengerid, String passengername, String gender, String email, String mobileno, String address, String passportnumber)
	{
		super();
		this.passengerid = passengerid;
		this.passengername = passengername;
		this.gender = gender;
		this.email = email;
		this.mobileno = mobileno;
		this.address = address;
		this.passportnumber=passportnumber;
	}

	//Generate Getter and Setter
	public Integer getPassengerid() {
		return passengerid;
	}

	public void setPassengerid(Integer passengerid) {
		this.passengerid = passengerid;
	}

	public String getPassengername() {
		return passengername;
	}

	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassportnumber() {
		return passportnumber;
	}

	public void setPassportnumber(String passportnumber) {
		this.passportnumber = passportnumber;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public void passengerflight(Flight flight2) {
		this.flight=flight2;
		
	}
	
	
}


