package com.edu.airlines.repository;

import java.sql.Time;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edu.airlines.model.Flight;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Integer> {
	
	List<Flight> findByFlightname(String flightname);
	List<Flight> findByDeplocation(String deplocation);
	List<Flight> findByDestlocation(String destlocation);
	List<Flight> findByDeparturetime(Time departuretime);
	List<Flight> findByArrivaltime(Time arrivaltime);
	List<Flight> findBySeatcapacity(Integer seatcapacity);

	
	

	
	

}

